package com.example.flowbatch

import android.annotation.SuppressLint
import android.content.Intent
import android.graphics.Color
import android.graphics.drawable.GradientDrawable
import android.net.Uri
import android.os.Bundle
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.ViewGroup.LayoutParams.MATCH_PARENT
import android.view.ViewGroup.LayoutParams.WRAP_CONTENT
import android.webkit.JavascriptInterface
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.*
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import org.json.JSONArray
import org.json.JSONObject

class MainActivity : AppCompatActivity() {

    private lateinit var web: WebView
    private lateinit var status: TextView
    private lateinit var fab: TextView
    private lateinit var panel: LinearLayout
    private lateinit var startBtn: Button

    private val flowUrl = "https://labs.google/fx/tools/flow"
    private val telegramUrl = "https://t.me/FlowAutomationTool"

    private fun openTelegram() {
        try {
            startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(telegramUrl)))
        } catch (e: Exception) {
            Toast.makeText(this, "Telegram link nahi khul paya", Toast.LENGTH_SHORT).show()
        }
    }

    // Pehli baar app kholne par ek baar channel join karne ka popup
    private fun maybeShowJoinDialog() {
        val prefs = getSharedPreferences("flowbatch", MODE_PRIVATE)
        if (prefs.getBoolean("tg_shown", false)) return
        prefs.edit().putBoolean("tg_shown", true).apply()
        AlertDialog.Builder(this)
            .setTitle("Telegram channel se jude")
            .setMessage("Updates, naye features aur help ke liye hamare Telegram channel @FlowAutomationTool ko join karo.")
            .setPositiveButton("Join karo") { _, _ -> openTelegram() }
            .setNegativeButton("Baad me", null)
            .show()
    }

    // Flow page me inject hone wali script
    private val automationJs = """
    (async function(prompts, ratio, waitSec, mode) {
      window.__stop = false;
      const sleep = ms => new Promise(r => setTimeout(r, ms));
      const say = m => { try { Android.status(m); } catch(e) {} };
      const prog = m => { try { Android.progress(m); } catch(e) {} };
      const txt = e => ((e.innerText || '') + ' ' + (e.getAttribute('aria-label') || '')).trim();
      const visible = e => { const r = e.getBoundingClientRect(); return r.width > 0 && r.height > 0; };

      // Asli touch jaisa click (pointer + mouse events)
      const realClick = el => {
        const r = el.getBoundingClientRect();
        const o = { bubbles: true, cancelable: true, view: window, button: 0,
                    clientX: r.left + r.width / 2, clientY: r.top + r.height / 2,
                    pointerId: 1, pointerType: 'touch', isPrimary: true };
        ['pointerdown', 'mousedown', 'pointerup', 'mouseup', 'click'].forEach(t => {
          const Ev = (t.indexOf('pointer') === 0 && window.PointerEvent) ? PointerEvent : MouseEvent;
          el.dispatchEvent(new Ev(t, o));
        });
      };
      const pressEnter = el => {
        el.focus();
        ['keydown', 'keypress', 'keyup'].forEach(t =>
          el.dispatchEvent(new KeyboardEvent(t, { key: 'Enter', code: 'Enter', keyCode: 13, which: 13, bubbles: true, cancelable: true })));
      };

      const findInput = () => {
        const c = [...document.querySelectorAll('textarea,[contenteditable="true"],[role="textbox"]')];
        return c.find(e => /create/i.test(e.getAttribute('placeholder') || e.getAttribute('aria-label') || e.getAttribute('data-placeholder') || ''))
          || c.find(e => e.tagName === 'TEXTAREA')
          || c[c.length - 1];
      };

      // Sirf prompt box ke aas-paas ke buttons
      const composerButtons = input => {
        let el = input;
        for (let i = 0; i < 10; i++) {
          el = el.parentElement;
          if (!el) break;
          const b = [...el.querySelectorAll('button,[role="button"]')].filter(visible);
          if (b.length >= 3) return b;
        }
        return [];
      };

      // Send button = prompt box ka sabse neeche-dayein wala button (➜)
      const sendBtn = input => {
        const b = composerButtons(input);
        if (!b.length) return null;
        const score = x => { const r = x.getBoundingClientRect(); return r.right + r.bottom; };
        return b.slice().sort((p, q) => score(q) - score(p))[0];
      };

      const setText = (el, t) => {
        el.focus();
        if (el.tagName === 'TEXTAREA' || el.tagName === 'INPUT') {
          const proto = el.tagName === 'TEXTAREA' ? HTMLTextAreaElement.prototype : HTMLInputElement.prototype;
          Object.getOwnPropertyDescriptor(proto, 'value').set.call(el, t);
          el.dispatchEvent(new Event('input', { bubbles: true }));
        } else {
          document.execCommand('selectAll', false, null);
          document.execCommand('insertText', false, t);
        }
      };
      const getText = el => (el.value !== undefined ? el.value : el.innerText) || '';

      const clickText = async re => {
        const el = [...document.querySelectorAll('button,[role="button"],[role="option"],[role="menuitem"],[role="tab"],div,span')]
          .find(e => visible(e) && e.children.length < 3 && re.test((e.innerText || '').replace(/\s+/g, ' ').trim()));
        if (el) { realClick(el); await sleep(600); return true; }
        return false;
      };
      const popupOpen = () => /Generating will use|Thinking level/i.test(document.body.innerText || '');

      // Settings popup: Image/Video + ratio
      const applySettings = async input => {
        const send = sendBtn(input);
        const set = composerButtons(input).find(x => x !== send && /banana|veo|imagen|model|x\s?[1-4]\b|aspect|ratio/i.test(txt(x)));
        if (!set) { say('Settings button nahi mila, default settings use hongi'); return; }
        realClick(set);
        await sleep(1000);
        if (mode) {
          const ok = await clickText(new RegExp('^' + mode + '$', 'i'));
          if (!ok) say('Mode "' + mode + '" nahi mila');
        }
        if (ratio) {
          const esc = ratio.replace(':', '\\s*:\\s*');
          const ok = await clickText(new RegExp('(^|\\s)' + esc + '\\s*$', 'i'));
          say(ok ? 'Ratio set: ' + ratio : 'Ratio "' + ratio + '" nahi mila, default use hoga');
        }
        if (popupOpen()) { realClick(set); await sleep(700); }
        if (popupOpen()) {
          document.dispatchEvent(new KeyboardEvent('keydown', { key: 'Escape', code: 'Escape', keyCode: 27, bubbles: true }));
          await sleep(500);
        }
      };

      let input = findInput();
      if (!input) { say('Prompt box nahi mila. Flow ka project kholo.'); Android.finished(); return; }
      await applySettings(input);

      for (let i = 0; i < prompts.length; i++) {
        if (window.__stop) { say('Stop hua: ' + i + '/' + prompts.length); Android.finished(); return; }
        prog((i + 1) + '/' + prompts.length);
        say('Prompt ' + (i + 1) + '/' + prompts.length + ' bhej raha hoon...');
        input = findInput();
        if (!input) { say('Prompt box nahi mila.'); Android.finished(); return; }
        setText(input, prompts[i]);
        await sleep(800);
        if (!getText(input).trim()) {
          input.dispatchEvent(new InputEvent('beforeinput', { inputType: 'insertText', data: prompts[i], bubbles: true, cancelable: true }));
          await sleep(500);
        }
        if (!getText(input).trim()) { say('Prompt box me text nahi ja raha. Screenshot bhejo.'); Android.finished(); return; }

        let go = null;
        for (let k = 0; k < 10; k++) {
          go = sendBtn(input);
          if (go && !go.disabled && go.getAttribute('aria-disabled') !== 'true') break;
          go = null;
          await sleep(500);
        }
        if (go) realClick(go); else pressEnter(input);
        await sleep(1800);

        // Check: submit hone par box khali ho jata hai
        let cur = findInput() || input;
        if (getText(cur).trim()) {
          pressEnter(cur);
          await sleep(1800);
          cur = findInput() || input;
        }
        if (getText(cur).trim()) {
          say('Generate button dabane par bhi submit nahi hua. Screen recording bhejo.');
          Android.finished();
          return;
        }

        for (let s = waitSec; s > 0 && !window.__stop; s--) {
          say('Prompt ' + (i + 1) + '/' + prompts.length + ' - wait ' + s + 's');
          await sleep(1000);
        }
      }
      say('Sab ' + prompts.length + ' prompts ho gaye.');
      Android.finished();
    })
    """.trimIndent()

    inner class Bridge {
        @JavascriptInterface
        fun status(msg: String) { runOnUiThread { status.text = msg } }

        @JavascriptInterface
        fun progress(p: String) { runOnUiThread { fab.text = p; fab.textSize = 13f } }

        @JavascriptInterface
        fun finished() {
            runOnUiThread {
                startBtn.isEnabled = true
                fab.text = "⚡"; fab.textSize = 22f
                Toast.makeText(this@MainActivity, "Flow Batch: kaam khatam", Toast.LENGTH_LONG).show()
            }
        }
    }

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    @SuppressLint("SetJavaScriptEnabled", "ClickableViewAccessibility")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        val root = FrameLayout(this)

        web = WebView(this).apply {
            settings.javaScriptEnabled = true
            settings.domStorageEnabled = true
            settings.userAgentString =
                "Mozilla/5.0 (Linux; Android 13; Pixel 7) AppleWebKit/537.36 " +
                "(KHTML, like Gecko) Chrome/124.0.0.0 Mobile Safari/537.36"
            webViewClient = WebViewClient()
            addJavascriptInterface(Bridge(), "Android")
            loadUrl(flowUrl)
        }
        root.addView(web, FrameLayout.LayoutParams(MATCH_PARENT, MATCH_PARENT))

        // ---------- Prompt panel (shuru me chhupa hua) ----------
        panel = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(Color.WHITE)
            setPadding(dp(12), dp(10), dp(12), dp(10))
            visibility = View.GONE
            elevation = dp(8).toFloat()
        }

        val promptsBox = EditText(this).apply {
            hint = "Saare prompts paste karo.\nHar line = 1 prompt, ya prompts ke beech '---' likho."
            setTextColor(Color.BLACK)
            setHintTextColor(Color.GRAY)
            minLines = 4
            maxLines = 8
            gravity = Gravity.TOP
        }
        panel.addView(promptsBox, LinearLayout.LayoutParams(MATCH_PARENT, WRAP_CONTENT))

        val row = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        val modeSpinner = Spinner(this).apply {
            adapter = ArrayAdapter(
                this@MainActivity, android.R.layout.simple_spinner_dropdown_item,
                listOf("Image", "Video")
            )
        }
        val spinner = Spinner(this).apply {
            adapter = ArrayAdapter(
                this@MainActivity, android.R.layout.simple_spinner_dropdown_item,
                listOf("16:9", "9:16", "1:1", "4:3", "3:4")
            )
        }
        val waitBox = EditText(this).apply {
            hint = "Wait (sec)"
            setText("60")
            setTextColor(Color.BLACK)
            inputType = android.text.InputType.TYPE_CLASS_NUMBER
            minEms = 4
        }
        row.addView(modeSpinner, LinearLayout.LayoutParams(0, WRAP_CONTENT, 1f))
        row.addView(spinner, LinearLayout.LayoutParams(0, WRAP_CONTENT, 1f))
        row.addView(waitBox, LinearLayout.LayoutParams(WRAP_CONTENT, WRAP_CONTENT))
        panel.addView(row)

        val buttons = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        startBtn = Button(this).apply { text = "Start" }
        val stopBtn = Button(this).apply { text = "Stop" }
        buttons.addView(startBtn, LinearLayout.LayoutParams(0, WRAP_CONTENT, 1f))
        buttons.addView(stopBtn, LinearLayout.LayoutParams(0, WRAP_CONTENT, 1f))
        panel.addView(buttons)

        status = TextView(this).apply {
            setTextColor(Color.DKGRAY)
            text = "Flow Batch v2.1  -  Pehle Flow me project kholo, phir Start dabao."
        }
        panel.addView(status)

        val tgBtn = TextView(this).apply {
            text = "✈  Telegram channel join karo"
            setTextColor(Color.WHITE)
            textSize = 14f
            gravity = Gravity.CENTER
            setPadding(dp(12), dp(10), dp(12), dp(10))
            background = GradientDrawable().apply {
                cornerRadius = dp(8).toFloat()
                setColor(Color.parseColor("#229ED9"))
            }
            setOnClickListener { openTelegram() }
        }
        panel.addView(tgBtn, LinearLayout.LayoutParams(MATCH_PARENT, WRAP_CONTENT).apply { topMargin = dp(8) })

        root.addView(panel, FrameLayout.LayoutParams(MATCH_PARENT, WRAP_CONTENT, Gravity.BOTTOM))

        // ---------- Floating icon (drag kar sakte ho, tap se panel khulta/band hota hai) ----------
        fab = TextView(this).apply {
            text = "⚡"
            textSize = 22f
            setTextColor(Color.WHITE)
            gravity = Gravity.CENTER
            background = GradientDrawable().apply {
                shape = GradientDrawable.OVAL
                setColor(Color.parseColor("#1A73E8"))
            }
            elevation = dp(10).toFloat()
        }
        val size = dp(58)
        root.addView(fab, FrameLayout.LayoutParams(size, size, Gravity.TOP or Gravity.START).apply {
            leftMargin = dp(300); topMargin = dp(180)
        })

        var downX = 0f; var downY = 0f; var startX = 0f; var startY = 0f; var dragged = false
        fab.setOnTouchListener { v, e ->
            when (e.action) {
                MotionEvent.ACTION_DOWN -> {
                    downX = e.rawX; downY = e.rawY; startX = v.x; startY = v.y; dragged = false
                }
                MotionEvent.ACTION_MOVE -> {
                    val dx = e.rawX - downX; val dy = e.rawY - downY
                    if (Math.abs(dx) > dp(8) || Math.abs(dy) > dp(8)) dragged = true
                    if (dragged) {
                        v.x = (startX + dx).coerceIn(0f, (root.width - v.width).toFloat())
                        v.y = (startY + dy).coerceIn(0f, (root.height - v.height).toFloat())
                    }
                }
                MotionEvent.ACTION_UP -> {
                    if (!dragged) {
                        panel.visibility = if (panel.visibility == View.VISIBLE) View.GONE else View.VISIBLE
                    }
                }
            }
            true
        }

        setContentView(root)
        maybeShowJoinDialog()

        startBtn.setOnClickListener {
            val raw = promptsBox.text.toString().trim()
            if (raw.isEmpty()) { status.text = "Pehle prompts paste karo"; return@setOnClickListener }
            val parts = if (raw.contains("---"))
                raw.split(Regex("(?m)^\\s*---\\s*$")).map { it.trim() }
            else raw.lines().map { it.trim() }
            // "12\. " ya "12. " jaise numbering hata do
            val list = parts
                .map { it.replace(Regex("^\\d+\\s*\\\\?\\.\\s*"), "") }
                .filter { it.isNotEmpty() }

            val wait = waitBox.text.toString().toIntOrNull() ?: 60
            val ratio = spinner.selectedItem.toString()
            val mode = modeSpinner.selectedItem.toString()
            startBtn.isEnabled = false
            panel.visibility = View.GONE   // start ke baad panel band, sirf floating icon dikhe

            val js = "($automationJs)(${JSONArray(list)}, ${JSONObject.quote(ratio)}, $wait, ${JSONObject.quote(mode)});"
            web.evaluateJavascript(js, null)
        }

        stopBtn.setOnClickListener {
            web.evaluateJavascript("window.__stop = true;", null)
            status.text = "Stop request bhej diya..."
        }
    }

    override fun onBackPressed() {
        if (panel.visibility == View.VISIBLE) panel.visibility = View.GONE
        else if (web.canGoBack()) web.goBack()
        else super.onBackPressed()
    }
}
